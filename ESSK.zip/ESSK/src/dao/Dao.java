/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.util.List;

/**
 *
 * @author BANE
 */
public abstract class Dao<T> {
    public Connection connect= ConnectDB.getInstance();
    //RECHERCHE
    public abstract T recherche(int id);
    //AJOUT
    public abstract void ajouter(T obj);
    //MODIFICATION
    public abstract void modifier(T obj, int id);
    //SUPPRESSION
    public abstract void supprimer(int id);
    //LISTE
    public abstract List<T> liste();
}
