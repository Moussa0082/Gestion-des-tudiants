/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import classe.Etudiant;
import classe.Paiement;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author BANE
 */
public class PaiementDao extends Dao<Paiement>{

    @Override
    public Paiement recherche(int id) {

         Paiement p = new Paiement();
        try {
            
            ResultSet result = this.connect.createStatement().executeQuery("Select * from paiement where id="+id);
            //si le resultat return quelque chose result.next() alors affiche les champs suivants
            if(result.next()){
                p.setId(result.getInt("id"));
                p.setPrenom_nom(result.getString("prenom_nom_etu"));
                p.setMotif(result.getString("motif"));
                p.setMt_paie(result.getInt("mt_paie"));
                p.setDate_paie(result.getString("date_paie"));
                p.setClasse(result.getString("classe"));
                p.setMt_restant(result.getInt("mt_restant"));
                p.setMt_annuel(result.getInt("mt_annuel"));
                
               
               
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(PaiementDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return p;

    }

    @Override
    public void ajouter(Paiement obj) {

         try {
            //insertion dans la base de données
            PreparedStatement pst = this.connect.prepareStatement("insert into paiement (prenom_nom_etu,motif,mt_paie,date_paie,classe,mt_restant,mt_annuel) values (?,?,?,?,?,?,?)");
            pst.setString(1, obj.getPrenom_nom());
            pst.setString(2, obj.getMotif());
            pst.setInt(3,obj.getMt_paie());
            pst.setString(4, obj.getDate_paie());
            pst.setString(5, obj.getClasse());
            pst.setInt(6, obj.getMt_restant());
            pst.setInt(7, obj.getMt_annuel());
           
            pst.execute();
        } catch (SQLException ex) {
            Logger.getLogger(PaiementDao.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public void modifier(Paiement obj, int id) {
      
           try {
            //insertion dans la base de données
            PreparedStatement pst = this.connect.prepareStatement("update paiment set prenom_nom_etu=?,motif=?,mt_paie=?,date_paie=?,classe=?,mt_restant=?,mt_annuel=?");
            pst.setString(1, obj.getPrenom_nom());
            pst.setString(2, obj.getMotif());
            pst.setInt(3,obj.getMt_paie());
            pst.setString(4,  obj.getDate_paie());
            pst.setString(5, obj.getClasse());
            pst.setInt(6, obj.getMt_restant());
            pst.setInt(7, obj.getMt_annuel());
           
            pst.execute();
        } catch (SQLException ex) {
            Logger.getLogger(PaiementDao.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public void supprimer(int id) {
  
      try {
            //insertion dans la base de données
            PreparedStatement pst = this.connect.prepareStatement("delete from paiement where id="+id);
            pst.execute();
            
        } catch (SQLException ex) {
            Logger.getLogger(PaiementDao.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public List<Paiement> liste() {

              Paiement p  = new Paiement();
         List<Paiement> pe = new ArrayList<>();
        try {
            
            ResultSet result = this.connect.createStatement().executeQuery("Select * from paiement ");
            //si le resultat retourne quelque chose result.next()
            while(result.next()){
                p.setId(result.getInt("id"));
                p.setPrenom_nom(result.getString("prenom_nom_etu"));
                p.setMotif(result.getString("motif"));
                p.setMt_paie(result.getInt("mt_paie"));
               // p.setMt_paie(result.getInt("mt_paie"));
                p.setDate_paie(result.getString("date_paie"));
                p.setClasse(result.getString("classe"));
                p.setMt_restant(result.getInt("mt_restant"));
                p.setMt_annuel(result.getInt("mt_annuel"));
               
                //ajoute l'etudiant a
                pe.add(p);
                //après l'ajout d'un etudiant passe au suivant 
                p = new Paiement();
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(PaiementDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return pe;

    }
    
}
