/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import classe.Etudiant;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author BANE
 */
public class EtudiantDao extends Dao <Etudiant>{

    @Override
    public Etudiant recherche(int id) {
    Etudiant et = new Etudiant();
        try {
            
            ResultSet result = this.connect.createStatement().executeQuery("Select * from inscription where id="+id);
            //si le resultat return quelque chose result.next()
            if(result.next()){
                et.setId(result.getInt("id"));
                et.setNom(result.getString("nom"));
                et.setPrenom(result.getString("prenom"));
                et.setSexe(result.getString("sexe"));
                et.setDate_naiss(result.getString("date_naiss"));
                et.setClasses(result.getString("classe"));
                et.setAdresse(result.getString("adresse"));
                et.setTelephone(result.getString("telephone"));
                et.setStatut_mat(result.getString("statut_mat"));
                et.setNom_prenom_pere(result.getString("prenom_nom_pere"));
                et.setNom_prenom_mere(result.getString("prenom_nom_mere"));
              
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(EtudiantDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return et;

    }

    @Override
    public void ajouter(Etudiant obj) {
    //ajouetr les champs dans la base de données
         try {
            //insertion dans la base de données
            PreparedStatement pst = this.connect.prepareStatement("insert into inscription (nom,prenom,sexe,date_naiss,classe,adresse,telephone,statut_mat,prenom_nom_pere,prenom_nom_mere) values (?,?,?,?,?,?,?,?,?,?)");
            pst.setString(1, obj.getNom());
            pst.setString(2, obj.getPrenom());
            pst.setString(3,obj.getSexe());
            pst.setString(4,  obj.getDate_naiss());
            pst.setString(5, obj.getClasses());
            pst.setString(6, obj.getAdresse());
            pst.setString(7, obj.getTelephone());
            pst.setString(8, obj.getStatut_mat());
            pst.setString(9, obj.getNom_prenom_pere());
            pst.setString(10, obj.getNom_prenom_mere());
            pst.execute();
        } catch (SQLException ex) {
            Logger.getLogger(EtudiantDao.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public void modifier(Etudiant obj, int id) {
    //modifier les champs dans la base de donnés
     try {
            //insertion dans la base de données
            PreparedStatement pst = this.connect.prepareStatement("update inscription set nom=?,prenom=?,sexe=?,date_naiss=?,classe=?,adresse=?,telephone=?,statut_mat=?,prenom_nom_pere=?,prenom_nom_mere=? where id="+id);
            pst.setString(1, obj.getNom());
            pst.setString(2, obj.getPrenom());
            pst.setString(3,obj.getSexe());
            pst.setString(4,  obj.getDate_naiss());
            pst.setString(5, obj.getClasses());
            pst.setString(6, obj.getAdresse());
            pst.setString(7, obj.getTelephone());
            pst.setString(8, obj.getStatut_mat());
            pst.setString(9, obj.getNom_prenom_pere());
            pst.setString(10, obj.getNom_prenom_mere());
           
            pst.execute();
        } catch (SQLException ex) {
            Logger.getLogger(EtudiantDao.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public void supprimer(int id) {

         try {
            //insertion dans la base de données
            PreparedStatement pst = this.connect.prepareStatement("delete from inscription where id="+id);
            pst.execute();
            
        } catch (SQLException ex) {
            Logger.getLogger(EtudiantDao.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public List<Etudiant> liste() {
 
            Etudiant et = new Etudiant();
         List<Etudiant> le = new ArrayList<>();
        try {
            
            ResultSet result = this.connect.createStatement().executeQuery("Select * from inscription ");
            //si le resultat retourne quelque chose result.next()
            while(result.next()){
                et.setId(result.getInt("id"));
                et.setNom(result.getString("nom"));
                et.setPrenom(result.getString("prenom"));
                et.setSexe(result.getString("sexe"));
                et.setDate_naiss(result.getString("date_naiss"));
                et.setClasses(result.getString("classe"));
                et.setAdresse(result.getString("adresse"));
                et.setTelephone(result.getString("telephone"));
                et.setStatut_mat(result.getString("statut_mat"));
                et.setNom_prenom_pere(result.getString("prenom_nom_pere"));
                et.setNom_prenom_mere(result.getString("prenom_nom_mere"));
               
                //ajoute l'etudiant a
                le.add(et);
                //après l'ajout d'un etudiant passe au suivant 
                et = new Etudiant();
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(EtudiantDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return le;
    }

    
    
}
