/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package essk;

import form.FrameChargement;
import form.FrameConnection;
import java.awt.Color;

/**
 *
 * @author BANE
 */
public class ESSK {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
         FrameChargement fc = new FrameChargement();
        fc.setVisible(true);
        FrameConnection fcn = new FrameConnection();
        
        try{
            for(int i = 0; i<=100; i++){
               Thread.sleep(110);
               fc.pourcent.setText(Integer.toString(i)+ "%");
               fc.barre.setValue(i);
               
                  if(i<=30){
                    fc.barre.setBackground(Color.green);
                    //ch.barre.setColor(Color.green);
                }
                 if(i>=30 && i<=60){
                    fc.barre.setBackground(Color.yellow);
                }
                  if(i>=60 && i<=100){
                    fc.barre.setBackground(Color.red);
                }
                
                if(i==100){
                    fc.setVisible(false);
                    //ac.setVisible(true);
                    fcn.setVisible(true);
                }
            }
                
            }catch(Exception e){
            
        }
            
        }
    }
    

