/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classe;



/**
 *
 * @author BANE
 */
public class Paiement {
    //Les attributs
    private int id;
    private String prenom_nom;
    private String motif;
    private int mt_paie;
    private String date_paie;
    private String classe;
    private int mt_restant;
    private int mt_annuel;
    
    //Le construteur par defaut

    public Paiement() {
    }


    //Le constructeur avec tous les attributs

    public Paiement(int id, String prenom_nom, String motif, int mt_paie, String date_paie, String classe,int mt_restant, int mt_annuel) {
        this.id = id;
        this.prenom_nom = prenom_nom;
        this.motif = motif;
        this.mt_paie = mt_paie;
        this.date_paie = date_paie;
        this.classe = classe;
        this.mt_restant = mt_restant;
        this.mt_annuel = mt_annuel;
    }
    
    //Constructeurs avec les attributs sans id

    public Paiement(String prenom_nom, String motif, int mt_paie, String date_paie, String classe, int mt_restant, int mt_annuel) {
        this.prenom_nom = prenom_nom;
        this.motif = motif;
        this.mt_paie = mt_paie;
        this.date_paie = date_paie;
        this.classe = classe;
        this.mt_restant = mt_restant;
        this.mt_annuel = mt_annuel;
    }
    
    
    //Getters et setters
    public int getId(){
        return id;
    }
    public void setId(int Id){
        this.id = id;
    }

    public String getPrenom_nom() {
        return prenom_nom;
    }

    public void setPrenom_nom(String prenom_nom) {
        this.prenom_nom = prenom_nom;
    }

    public String getMotif() {
        return motif;
    }

    public void setMotif(String motif) {
        this.motif = motif;
    }

    public int getMt_paie() {
        return mt_paie;
    }

    public void setMt_paie(int mt_paie) {
        this.mt_paie = mt_paie;
    }

    public String getDate_paie() {
        return date_paie;
    }

    public void setDate_paie(String date_paie) {
        this.date_paie = date_paie;
    }

    public String getClasse() {
        return classe;
    }

    public void setClasse(String classe) {
        this.classe = classe;
    }
    
    public int getMt_restant(){
        return mt_restant;
    }
    
    public void setMt_restant(int mt_restant){
        this.mt_restant = mt_restant;
    }

    public int getMt_annuel() {
        return mt_annuel;
    }

    public void setMt_annuel(int mt_annuel) {
        this.mt_annuel = mt_annuel;
    }
       
}
