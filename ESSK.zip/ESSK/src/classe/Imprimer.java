/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classe;

import java.text.MessageFormat;
import javax.swing.JOptionPane;
import javax.swing.JTable;

/**
 *
 * @author BANE
 */
public class Imprimer {
    
    public static void imprimerJtable(JTable jt, String titre){
       MessageFormat entete = new MessageFormat(titre);
       MessageFormat pied = new MessageFormat("ESSK");
        
       try{
           jt.print(JTable.PrintMode.FIT_WIDTH, entete, pied);
           
       }catch(Exception e){
           JOptionPane.showMessageDialog(null,"Erreur:\n"+e, "Impression",JOptionPane.ERROR_MESSAGE);
       }
    
    }
    
}
