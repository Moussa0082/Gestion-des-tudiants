/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classe;

import java.util.Date;

/**
 *
 * @author BANE
 */
public class Etudiant {
    //Les attributs
    private int id;
    private String nom;
    private String Prenom;
    private String sexe;
    private String date_naiss;
    private String classes;
    private String adresse;
    private String telephone;
    private String statut_mat;
    private String nom_prenom_pere;
    private String nom_prenom_mere;
    
    //Constructeur par défaut

    public Etudiant() {
    }
    //Constructeur avec tous les attributs

    public Etudiant(int id, String nom, String Prenom, String sexe, String date_naiss, String classes, String adresse, String telephone, String statut_mat, String nom_prenom_pere, String nom_prenom_mere) {
        this.id = id;
        this.nom = nom;
        this.Prenom = Prenom;
        this.sexe = sexe;
        this.date_naiss = date_naiss;
        this.classes = classes;
        this.adresse = adresse;
        this.telephone = telephone;
        this.statut_mat = statut_mat;
        this.nom_prenom_pere = nom_prenom_pere;
        this.nom_prenom_mere = nom_prenom_mere;
    }
    //Constructeur avec les attributs sans l'id

    public Etudiant(String nom, String Prenom, String sexe, String date_naiss, String classes, String adresse, String telephone, String statut_mat, String nom_prenom_pere, String nom_prenom_mere) {
        this.nom = nom;
        this.Prenom = Prenom;
        this.sexe = sexe;
        this.date_naiss = date_naiss;
        this.classes = classes;
        this.adresse = adresse;
        this.telephone = telephone;
        this.statut_mat = statut_mat;
        this.nom_prenom_pere = nom_prenom_pere;
        this.nom_prenom_mere = nom_prenom_mere;
    }
    //Getters et Setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return Prenom;
    }

    public void setPrenom(String Prenom) {
        this.Prenom = Prenom;
    }

    public String getSexe() {
        return sexe;
    }

    public void setSexe(String sexe) {
        this.sexe = sexe;
    }

    public String getDate_naiss() {
        return date_naiss;
    }

    public void setDate_naiss(String date_naiss) {
        this.date_naiss = date_naiss;
    }

    public String getClasses() {
        return classes;
    }

    public void setClasses(String classes) {
        this.classes = classes;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getStatut_mat() {
        return statut_mat;
    }

    public void setStatut_mat(String statut_mat) {
        this.statut_mat = statut_mat;
    }

    public String getNom_prenom_pere() {
        return nom_prenom_pere;
    }

    public void setNom_prenom_pere(String nom_prenom_pere) {
        this.nom_prenom_pere = nom_prenom_pere;
    }

    public String getNom_prenom_mere() {
        return nom_prenom_mere;
    }

    public void setNom_prenom_mere(String nom_prenom_mere) {
        this.nom_prenom_mere = nom_prenom_mere;
    }
    
    
    
}
